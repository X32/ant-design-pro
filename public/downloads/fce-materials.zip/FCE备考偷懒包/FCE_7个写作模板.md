# FCE 7个写作模板

> FCE写作Part 2共有7种文体，掌握这些模板，考试直接套用

---

## 📌 写作评分标准

| 维度 | 占比 | 要点 |
|------|------|------|
| 内容 | 25% | 是否覆盖所有要点 |
| 组织 | 25% | 结构清晰，衔接自然 |
| 语言 | 25% | 词汇丰富，语法正确 |
| 目标读者 | 25% | 是否达到写作目的 |

---

## 模板1: Essay (议论文)

### 📋 题目特征
- 讨论某个话题
- 表达观点
- 给出理由和例子

### 📝 万能模板

```
Introduction (40-50词)
---------------------
Nowadays, [TOPIC] has become a controversial issue. While some people believe that [VIEWPOINT A], others argue that [VIEWPOINT B]. In this essay, I will discuss both sides and give my own opinion.

Body Paragraph 1 (60-70词)
---------------------
On the one hand, there are several reasons why [VIEWPOINT A]. Firstly, [REASON 1]. For example, [EXAMPLE]. Secondly, [REASON 2]. This means that [EXPLANATION].

Body Paragraph 2 (60-70词)
---------------------
On the other hand, [VIEWPOINT B] also has its advantages. To begin with, [REASON 1]. For instance, [EXAMPLE]. Moreover, [REASON 2]. As a result, [EXPLANATION].

Conclusion (30-40词)
---------------------
In conclusion, while both sides have valid points, I believe that [YOUR OPINION]. This is because [REASON]. Therefore, [FINAL THOUGHT].
```

### ✨ 高分句型

| 功能 | 句型 |
|------|------|
| 引入话题 | It is widely believed that... / It is often said that... |
| 表达观点 | In my opinion,... / From my perspective,... |
| 列举理由 | Firstly,... Secondly,... Moreover,... Furthermore,... |
| 举例说明 | For example,... / For instance,... / Such as... |
| 总结观点 | In conclusion,... / To sum up,... / All in all,... |

---

## 模板2: Article (文章)

### 📋 题目特征
- 为杂志/校报写文章
- 吸引读者兴趣
- 通常有标题

### 📝 万能模板

```
Title: [EYE-CATCHING TITLE]
=====================

Introduction (40-50词)
---------------------
Have you ever wondered [QUESTION RELATED TO TOPIC]? Well, you're not alone. [TOPIC] is something that affects all of us, and in this article, I'll be sharing my thoughts on [MAIN TOPIC].

Body Paragraph 1 (60-70词)
---------------------
To begin with, let's consider [POINT 1]. [DEVELOP POINT]. What's more, [ADDITIONAL POINT]. For example, [EXAMPLE from your experience].

Body Paragraph 2 (60-70词)
---------------------
Another important aspect is [POINT 2]. [DEVELOP POINT]. Did you know that [INTERESTING FACT]? This shows that [EXPLANATION].

Conclusion (30-40词)
---------------------
So, what's the answer? In my view, [YOUR OPINION]. Why not [CALL TO ACTION]? After all, [FINAL MEMORABLE STATEMENT].
```

### ✨ 高分句型

| 功能 | 句型 |
|------|------|
| 吸引注意 | Have you ever...? / Did you know that...? |
| 引入话题 | Let's consider... / Let's think about... |
| 添加信息 | What's more,... / Not only that, but... |
| 互动读者 | You might be wondering... / You may think... |

---

## 模板3: Email/Formal Letter (邮件/正式信函)

### 📋 题目特征
- 给朋友/老师/机构写信
- 正式程度取决于收件人
- 需要完成特定任务

### 📝 Email给朋友 (非正式)

```
Subject: [CLEAR SUBJECT]
=====================

Hi [NAME],

Opening (20-30词)
-----------------
Thanks for your email. It was great to hear from you! I'm writing to [PURPOSE OF EMAIL].

Main Content (80-100词)
-----------------------
Regarding [TOPIC 1], I think [YOUR OPINION]. [DEVELOP POINT]. Also, [ADDITIONAL POINT].

About [TOPIC 2], [RESPONSE]. The reason is [REASON]. For example, [EXAMPLE].

Closing (20-30词)
-----------------
Anyway, I'd better go now. Hope to hear from you soon!

All the best,
[YOUR NAME]
```

### 📝 Formal Letter (正式信函)

```
[Your Address]
[Date]

Dear [TITLE + LAST NAME / Sir or Madam],

Opening (30-40词)
-----------------
I am writing to [PURPOSE]. [ADDITIONAL CONTEXT].

Main Content (80-100词)
-----------------------
First of all, [POINT 1]. [DEVELOP POINT]. I would like to [REQUEST/STATEMENT].

Furthermore, [POINT 2]. [DEVELOP POINT]. I believe that [OPINION].

Closing (20-30词)
-----------------
I look forward to hearing from you.

Yours faithfully, [if Dear Sir/Madam]
Yours sincerely, [if Dear + Name]
[YOUR FULL NAME]
```

---

## 模板4: Report (报告)

### 📋 题目特征
- 分析某个情况
- 提出建议
- 结构清晰，有标题

### 📝 万能模板

```
Title: Report on [TOPIC]
=====================

To: [RECIPIENT]
From: [YOUR NAME]
Date: [DATE]
Subject: [BRIEF DESCRIPTION]

Introduction (30-40词)
---------------------
The purpose of this report is to [PURPOSE]. It will examine [MAIN POINTS] and provide recommendations.

Current Situation (50-60词)
--------------------------
At present, [DESCRIBE SITUATION]. According to [SOURCE], [STATISTIC/FACT]. Additionally, [ADDITIONAL INFORMATION]. This has resulted in [CONSEQUENCE].

Findings/Analysis (60-70词)
---------------------------
The investigation revealed several key points. Firstly, [FINDING 1]. For example, [EVIDENCE]. Secondly, [FINDING 2]. This suggests that [IMPLICATION].

Recommendations (50-60词)
-------------------------
Based on these findings, I would recommend the following:
1. [RECOMMENDATION 1] - This would [BENEFIT].
2. [RECOMMENDATION 2] - As a result, [BENEFIT].
3. [RECOMMENDATION 3] - Therefore, [BENEFIT].

Conclusion (20-30词)
--------------------
In conclusion, [SUMMARY]. If these recommendations are implemented, [EXPECTED OUTCOME].
```

---

## 模板5: Review (评论)

### 📋 题目特征
- 评论电影、书籍、餐厅等
- 给出评价
- 可能需要推荐

### 📝 万能模板

```
Title: A Review of [NAME]
=====================

Introduction (40-50词)
---------------------
Last [TIME], I [EXPERIENCE]. [NAME] is a [TYPE] located in/at [LOCATION]. I had heard a lot about it, so I decided to [ACTION]. Here's what I thought.

Description (60-70词)
---------------------
[NAME] offers [DESCRIPTION]. The [FEATURE] was particularly impressive because [REASON]. What's more, [ADDITIONAL FEATURE]. However, [NEGATIVE POINT].

Evaluation (50-60词)
--------------------
Overall, I was [IMPRESSED/DISAPPOINTED] with [ASPECT]. The [FEATURE] was [POSITIVE/NEGATIVE] because [REASON]. On the other hand, [ANOTHER ASPECT] could have been better.

Recommendation (30-40词)
------------------------
Would I recommend [NAME]? The answer is [YES/NO]. If you enjoy [TYPE], you should definitely [ACTION]. I would give it [RATING] out of 5.
```

### ✨ 评论常用词汇

| 正面 | 负面 |
|------|------|
| impressive | disappointing |
| outstanding | overrated |
| excellent | poor |
| highly recommended | not recommended |
| worth visiting | waste of time |

---

## 模板6: Story (故事)

### 📋 题目特征
- 记叙文
- 可能有开头句或结尾句要求
- 需要情节发展

### 📝 万能模板

```
Opening (40-50词)
-----------------
[IF GIVEN: Use the required opening sentence]
It was a [ADJECTIVE] day when [SITUATION]. I had [CONTEXT] and was feeling [EMOTION]. Little did I know that [FORESHADOWING].

Development (80-100词)
----------------------
Suddenly, [EVENT]. I couldn't believe my eyes when [REACTION]. [CHARACTER] said, "[DIALOGUE]." I immediately [ACTION].

As I [ACTION], I noticed [DETAIL]. My heart was beating fast as [EMOTION]. Then, [NEXT EVENT]. Despite [OBSTACLE], I managed to [RESOLUTION].

Ending (40-50词)
----------------
In the end, [OUTCOME]. Looking back, I realize [REFLECTION]. It taught me that [LESSON LEARNED]. I will never forget [MEMORABLE MOMENT].
```

### ✨ 故事常用词汇

| 时间连接词 | 情感词汇 |
|------------|----------|
| Suddenly | terrified |
| Just then | relieved |
| Meanwhile | excited |
| Eventually | disappointed |
| At that moment | grateful |

---

## 模板7: Letter of Application (申请信)

### 📋 题目特征
- 申请工作/课程/奖学金
- 突出自己的资格和技能
- 正式语气

### 📝 万能模板

```
[Your Address]
[Date]

Dear [TITLE + LAST NAME / Sir or Madam],

Opening (40-50词)
-----------------
I am writing to apply for [POSITION/OPPORTUNITY], which I saw advertised in [WHERE]. I am very interested in this opportunity because [REASON].

Qualifications (70-80词)
------------------------
I believe I am well-suited for this position for several reasons. Firstly, I have [QUALIFICATION/EXPERIENCE]. During my time at [PLACE], I [ACHIEVEMENT]. This gave me valuable experience in [SKILL].

Moreover, I possess [SKILL], which I developed through [HOW]. I am also [PERSONAL QUALITY], which I believe is essential for [REASON].

Motivation (40-50词)
--------------------
I am particularly attracted to this [POSITION/OPPORTUNITY] because [REASON]. I am eager to [GOAL] and believe this would help me [BENEFIT].

Availability/Closing (30-40词)
------------------------------
I am available for [INTERVIEW/START DATE]. Thank you for considering my application. I look forward to hearing from you.

Yours sincerely,
[YOUR FULL NAME]
```

---

## 🔥 写作万能连接词

### 表示顺序
- First of all / To begin with
- Secondly / Moreover / Furthermore
- Finally / Lastly / In conclusion

### 表示对比
- However / Nevertheless / On the other hand
- Although / Despite / In spite of
- While / Whereas

### 表示因果
- Because / Since / As
- Therefore / Consequently / As a result
- So / Thus / Hence

### 表示举例
- For example / For instance
- Such as / Including
- In particular / Specifically

### 表示强调
- In fact / Indeed
- Especially / Particularly
- What's more / Not only that

---

## ✍️ 写作检查清单

提交前检查：

- [ ] 是否覆盖所有要点？
- [ ] 字数是否在140-190词之间？
- [ ] 是否使用了多种连接词？
- [ ] 是否使用了复杂句式？
- [ ] 拼写和语法是否正确？
- [ ] 语气是否恰当？

---

*背熟这7个模板，FCE写作稳拿高分！*
